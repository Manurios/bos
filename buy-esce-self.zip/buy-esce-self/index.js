// MENCOBA SELF BOT BANG
// Aqulzz :V
// Ini WE EM
const { WAConnection } = require("@adiwajshing/baileys")
const qrcode = require("qrcode-terminal")
const moment = require("moment-timezone")
const fs = require("fs")
const time = moment().tz('Asia/Jakarta').format("HH:mm:ss")

require('./xinz.js')
nocache('./xinz.js', module => console.log(`'${module}' Updated!`))

async function starts() {
    const xinz = new WAConnection()
    xinz.on('qr', qr => {
        qrcode.generate(qr, { small: true })
        console.log(`[ ${time} ] Scan Pack`)
    })

    xinz.on('credentials-updated', () => {
        const authInfo = xinz.base64EncodedAuthInfo()
        console.log(`credentials updated!`)
    
        fs.writeFileSync('./aqulzz.json', JSON.stringify(authInfo, null, '\t'))
    })
    
    fs.existsSync('./aqulzz.json') && xinz.loadAuthInfo('./aqulzz.json')
    
    xinz.connect();

    xinz.on('message-update', async (geps) => { // GW DAPAT DARI MR.G3P5
        require('./geps.js')(xinz, geps)
    })

    xinz.on('message-new', async (mek) => {
        require('./xinz.js')(xinz, mek)
    })
}
/**
 * Uncache if there is file change
 * @param {string} module Module name or path
 * @param {function} cb <optional> 
 */
function nocache(module, cb = () => { }) {
    console.log('Module', `'${module}'`, 'is now being watched for changes')
    fs.watchFile(require.resolve(module), async () => {
        await uncache(require.resolve(module))
        cb(module)
    })
}

/**
 * Uncache a module
 * @param {string} module Module name or path
 */
function uncache(module = '.') {
    return new Promise((resolve, reject) => {
        try {
            delete require.cache[require.resolve(module)]
            resolve()
        } catch (e) {
            reject(e)
        }
    })
}
starts()