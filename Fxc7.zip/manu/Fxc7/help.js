// menu fitur bot
const help = (prefix, instagram, yt, name, pushname2, user, limitt, uptime, jam, tanggal, groupName) => { 
	return `
\`\`\`Follow Owner Instagram\`\`\`
${instagram}

\`\`\`UNTUK FITUR TERUPDATE SILAHKAN KETIK\`\`\` *${prefix}infobot*

\`\`\`TOLONG UNTUK MEMBERI JEDA 5 DETIK\`\`\`
\`\`\`UNTUK MENCEGAH PEMBLOKIRAN⚠\`\`\`

╭─────≽「 *REGULATION ${name}* 」
┴
┃❀°  \`\`\`NAME USER:\`\`\` *${pushname2}*
┃❀°  \`\`\`NAME GROUP:\`\`\` *${groupName}*
┃❀°  \`\`\`LIMIT:\`\`\` *${limitt} perhari*
┃❀°  \`\`\`ACTIVE:\`\`\` ${kyun(uptime)}
┃❀°  \`\`\`HOUR:\`\`\` *${jam} WIB*
┃❀°  \`\`\`DATE:\`\`\` *${tanggal}*
┃❀°  \`\`\`VERSION:\`\`\` *0.0.0*
┃❀°  \`\`\`DONATE:\`\`\` *2%*
┃❀°  \`\`\`USER:\`\`\` *${user.length} User*
┬
╰────────────────────────

╭─────≽「 *ABOUT ${name}* 」
┴
┃➢ *${prefix}report lapor bug*
│ Untuk Melaporkan Bug Ke Owner
┃➢ *${prefix}info*
│ Untuk Menampilkan Info Bot
┃➢ *${prefix}donasi*
│ Jika Berkenan Untuk Donasi
┃➢ *${prefix}owner*
│ Bot Otomatis Mengirimkan Nomer Owner
┃➢ *${prefix}speed*
│ Untuk Mengetahui Seberapa Cepat Respon Bot
┃➢ *${prefix}daftar*
│ Untuk Mendaftar Yang Belom Terdaftar
┃➢ *${prefix}limit*
│ Untuk Cek Limit Anda
┃➢ *${prefix}blocklist*
│ Untuk Mengetahui Berapa Kontak Yg Diblock
┃➢ *${prefix}banlist*
│ Untuk Mengetahui Berapa Kontak Yg Dibanned
┃➢ *${prefix}premiumlist*
│ Untuk Mengetahui Berapa Kontak Yg Menjadi User Premium
┃➢ *${prefix}bahasa*
│ Untuk Fitur text to speech
┃➢ *${prefix}wame*
│ Untuk Membuat Link Nomer WA Anda
┬
╰────────────────────────

╭──≽「 *FITUR SIMPLE ${name}* 」
┴
┃➢ *${prefix}menucreator*
│ Menampilkan Beberapa Fitur Image Maker
┃➢ *${prefix}menumedia*
│ Menampilkan Beberapa Fitur Stalking & Downloader
┃➢ *${prefix}menugrup*
│ Menampilkan Beberapa Fitur Khusus Di group
┃➢ *${prefix}menuothers*
│ Menampilkan Beberapa Fitur Random
┃➢ *${prefix}menuprimbon*
│ Menampilkan Beberapa Fitur primbon Jodoh, DLL
┃➢ *${prefix}menuinformasi*
│ Menampilkan Beberapa Fitur Informasi cuaca, DLL
┃➢ *${prefix}menufun*
│ Menampilkan Beberapa Fitur Untuk Game
┃➢ *${prefix}menuscrapper*
│ Menampilkan Beberapa Fitur scrapper
┃➢ *${prefix}menuencrypt*
│ Menampilkan Beberapa Fitur Encrypt & Decrypt
┃➢ *${prefix}menuspam*
│ Menampilkan Beberapa Fitur Spam
┃➢ *${prefix}menupremium*
│ Menampilkan Beberapa Fitur Untuk User Premium
┃➢ *${prefix}menuowner*
│ Menampilkan Beberapa Fitur Khusus Owner
┬
╰────────────────────────

╭────≽「 *SUPPORT ${name}* 」
┴
│➲ *FXC7*
│➲ *MHANKBARBAR*
│➲ *MANURIOS*
│➲ *PENGISI SUARA*
│➲ *MY TEAM FXC7 BOT*
│➲ *PENYEDIA REST API*
│➲ *CONTENT CREATOR BOT WHATSAPP*
┬
╰──────≽ *Created © Manurios*`
}

exports.help = help

// penghitung aktif bot
function kyun(seconds){
  function pad(s){
    return (s < 10 ? '0' : '') + s;
  }
  var hours = Math.floor(seconds / (60*60));
  var minutes = Math.floor(seconds % (60*60) / 60);
  var seconds = Math.floor(seconds % 60);
  return `*${pad(hours)} Jam ${pad(minutes)} Menit ${pad(seconds)} Detik*`
}

// info bot 
const bottt = (prefix) => {
return `
\`\`\`Untuk Sekarang Bot Hanya Bisa Digunakan Di Group Karna,\`\`\` \n*Kalian Yang Menggunakan Bot Terlalu Spam*

*NOTE:*
Jika Bot Ini Ada Di Grup Anda Admin Grup Suruh Aktifkan Bot Dengan Cara ${prefix}bott aktif

*Adapun Daftar Menu Yang Di Public Sama Owner Dan Bisa Kalian Gunakan Tanpa Di Group*

- ${prefix}google
- ${prefix}brainly
- ${prefix}kalkulator
- ${prefix}ytsearch
- ${prefix}moddroid
- ${prefix}happymod
- ${prefix}playstore
- ${prefix}tanggaljadian
- ${prefix}stiker
- ${prefix}resepmasakan
- ${prefix}film
- ${prefix}infocuaca
- ${prefix}infogempa
- ${prefix}tahta
- ${prefix}igstalk
- ${prefix}tiktokstalk
- ${prefix}instastory
- ${prefix}translate
- ${prefix}quran
- ${prefix}tafsirquran
- ${prefix}lirik
- ${prefix}chord
- ${prefix}nulis
- ${prefix}puisiimg
- ${prefix}randomkpop
- ${prefix}quotes
- ${prefix}bucin
- ${prefix}artinama
- ${prefix}wattpad
- ${prefix}jarak
- ${prefix}infoalamat
- ${prefix}mimpi
- ${prefix}bacotandilan
- ${prefix}instavid
- ${prefix}instaimg

*Apa Yang Terbaru??*

~ random gambar KPOP ✓
~ random gambar EXO ✓
~ Fitur Anti virtex ✓
~ Fitur Anti Link ✓
~ Bacotan Dilan ✓
~ wattpad searching ✓
~ puisi dalam bentuk gambar ✓
~ Mencari resep masakan ✓
~ text to picture (bisa request warna) ✓
~ Tiktok scrapper ✓
~ instagram image downloader ✓ => command: ${prefix}instaimg link url
~ instagram video downloader ✓ => command: ${prefix}instavid link url

~ convert mp3/mp4 ─≽ suara tupai ✓
~ convert mp3/mp4 ─≽ suara bass ✓
~ convert mp3/mp4 ─≽ suara slow ✓
~ convert mp3/mp4 ─≽ suara gemuk ✓

~ Tampilan Simple Menu ✓

~ Anti Virtex on/off ✓ command: ${prefix}antivirtex on
- *Gunakan Apabila Ada Yg Ngirim Virtex*

~ Anti Virtex ✓ => command: ${prefix}antivirtexx
- *Bot Akan Mengirimkan Teks Biar Member Tidak Mengalami Lag*

~ Xnxx scrapper ✓

\`\`\`HUB OWNER 62831419269345 JIKA ADA PERTANYAAN\`\`\`
_${instagram}_
*Fitur Error*

~ Google scrapper
~ Anime Picture
~ Stiker
~ Trigger
~ Wasted
~ AnimeKiss
~ AnimeHug
~ Ttp
~ StikerGif

`
}
exports.bottt = bottt
// donasi menu
const donasi = (name) => { 
	return `       
Mau donasi ya kak ✨
 اتَّقوا النَّارَ ولو بشقِّ تمرةٍ ، فمن لم يجِدْ فبكلمةٍ طيِّبةٍ
“*jauhilah api neraka, walau hanya dengan bersedekah sebiji kurma (sedikit). Jika kamu tidak punya, maka bisa dengan kalimah thayyibah” [HR. Bukhari 6539, Muslim 1016*]_
═══════════════════

╭─≽「 *DONASI AGAR BOT TETAP ONLINE* 」
┴
│
│✓ \`\`\`Pulsa: 0831419269353\`\`\`
│
│✓ \`\`\`SHOPEEPAY: 0831419269353\`\`\`
│
┬
╰─────≽「 *BY ${name}* 」

Untuk Kelangsungan Hidup Bot Karna Kuota Mahal:'
`
}
exports.donasi = donasi

// bahasa list
const bahasa = (prefix) => {
return `
List Bahasa Untuk Command *${prefix}tts*

  af: Afrikaans
  sq: Albanian
  ar: Arabic
  hy: Armenian
  ca: Catalan
  zh: Chinese
  zh-cn: Chinese (Mandarin/China)
  zh-tw: Chinese (Mandarin/Taiwan)
  zh-yue: Chinese (Cantonese)
  hr: Croatian
  cs: Czech
  da: Danish
  nl: Dutch
  en: English
  en-au: English (Australia)
  en-uk: English (United Kingdom)
  en-us: English (United States)
  eo: Esperanto
  fi: Finnish
  fr: French
  de: German
  el: Greek
  ht: Haitian Creole
  hi: Hindi
  hu: Hungarian
  is: Icelandic
  id: Indonesian
  it: Italian
  ja: Japanese
  ko: Korean
  la: Latin
  lv: Latvian
  mk: Macedonian
  no: Norwegian
  pl: Polish
  pt: Portuguese
  pt-br: Portuguese (Brazil)
  ro: Romanian
  ru: Russian
  sr: Serbian
  sk: Slovak
  es: Spanish
  es-es: Spanish (Spain)
  es-us: Spanish (United States)
  sw: Swahili
  sv: Swedish
  ta: Tamil
  th: Thai
  tr: Turkish
  vi: Vietnamese
  cy: Welsh
`
}
exports.bahasa = bahasa

// Limit
const limitcount = (limitCounts) => {
        return`
Limit Kamu: ${limitCounts}
`
}
exports.limitcount = limitcount