const ownerrr = (prefix, pushname2, groupName, user, name) => {
return `

╭─────≽「 *REGULATION ${name}* 」
┴
┃❀°  \`\`\`NAMA USER:\`\`\` *${pushname2}*
┃❀°  \`\`\`NAMA GRUP:\`\`\` *${groupName}*
┃❀°  \`\`\`VERSION:\`\`\` *0.0.0*
┃❀°  \`\`\`USER TERDAFTAR:\`\`\` *${user.length} User*
┬
╰────────────────────────

╭────────≽「 *OWNER ONLY* 」
┴
┃➢ ${prefix}addprem *@mentioned*
┃➢ ${prefix}removeprem *@mentioned*
┃➢ ${prefix}setmemlimit
┃➢ ${prefix}setlimit
┃➢ ${prefix}setreply
┃➢ ${prefix}setprefix
┃➢ ${prefix}setnamebot
┃➢ ${prefix}setppbot
┃➢ ${prefix}sharelock
┃➢ ${prefix}bc
┃➢ ${prefix}bcgc
┃➢ ${prefix}ban
┃➢ ${prefix}unban
┃➢ ${prefix}block
┃➢ ${prefix}unblock
┃➢ ${prefix}clearall
┃➢ ${prefix}delete
┃➢ ${prefix}clone
┃➢ ${prefix}getses
┃➢ ${prefix}leave
┬
╰────────────────────────
`
}
exports.ownerrr = ownerrr