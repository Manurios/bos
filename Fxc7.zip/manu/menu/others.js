const others = (prefix, pushname2, groupName, user, name) => {
return `

╭─────≽「 *REGULATION ${name}* 」
┴
┃❀°  \`\`\`NAMA USER:\`\`\` *${pushname2}*
┃❀°  \`\`\`NAMA GRUP:\`\`\` *${groupName}*
┃❀°  \`\`\`VERSION:\`\`\` *0.0.0*
┃❀°  \`\`\`USER TERDAFTAR:\`\`\` *${user.length} User*
┬
╰────────────────────────

╭─────≽「 *OTHERS MENU* 」
┴
┃➢ ${prefix}randomexo
┃➢ ${prefix}randombts
┃➢ ${prefix}randomKPOP
┃➢ ${prefix}anjing
┃➢ ${prefix}kucing
┃➢ ${prefix}testime
┃➢ ${prefix}quotes
┃➢ ${prefix}katabijak
┃➢ ${prefix}bucin
┃➢ ${prefix}bacotandilan
┃➢ ${prefix}pantun
┃➢ ${prefix}hekerbucin
┃➢ ${prefix}puisiimg
┃➢ ${prefix}katailham
┬
╰────────────────────────

╭─────≽「 *ISLAMIC MENU* 」
┴
┃➢ ${prefix}jadwalsholat *City*
┃➢ ${prefix}quran
┃➢ ${prefix}quransurah *Number*
┬
╰────────────────────────
`
}
exports.others = others