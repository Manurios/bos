const encrypt = (prefix, pushname2, groupName, user, name) => {
return `
╭─────≽「 *REGULATION ${name}* 」
┴
┃❀°  \`\`\`NAMA USER:\`\`\` *${pushname2}*
┃❀°  \`\`\`NAMA GRUP:\`\`\` *${groupName}*
┃❀°  \`\`\`VERSION:\`\`\` *0.0.0*
┃❀°  \`\`\`USER TERDAFTAR:\`\`\` *${user.length} User*
┬
╰────────────────────────

╭─────≽「 *ENCRYPT & DECRYPT* 」
┴
┃➢ ${prefix}encode64 *String*
┃➢ ${prefix}decode64 *Encrypt*
┃➢ ${prefix}hexaencode *String*
┃➢ ${prefix}hexadecode *Encrypt*
┃➢ ${prefix}encbinary *String*
┃➢ ${prefix}decbinary *Encrypt*
┃➢ ${prefix}encoctal *String*
┃➢ ${prefix}decoctal *Encrypt*
┃➢ ${prefix}dorking *Dork*
┃➢ ${prefix}pastebin *Text*
┃➢ ${prefix}tinyurl *Link*
┃➢ ${prefix}bitly *Link*
┃➢ ${prefix}hashidentifier *Encrypt Hash*
┬
╰────────────────────────
`
}
exports.encrypt = encrypt