const creator = (prefix, pushname2, groupName, user, name) => {
return `

\`\`\`UNTUK FITUR TERUPDATE SILAHKAN KETIK\`\`\` *${prefix}infobot*

╭─────≽「 *REGULATION ${name}* 」
┴
┃❀°  \`\`\`NAMA USER:\`\`\` *${pushname2}*
┃❀°  \`\`\`NAMA GRUP:\`\`\` *${groupName}*
┃❀°  \`\`\`VERSION:\`\`\` *0.0.0*
┃❀°  \`\`\`USER TERDAFTAR:\`\`\` *${user.length} User*
┬
╰────────────────────────

╭─────≽「 *CREATOR MENU* 」
┴
┃➢ ${prefix}quotemaker Txt/Wtrmk/Theme*
┃➢ ${prefix}nulis *Nama/Kelas/Text*
┃➢ ${prefix}croman *Text And Text*
┃➢ ${prefix}slide *Text*
┃➢ ${prefix}trigger *ERROR⚠*
┃➢ ${prefix}wasted *ERROR⚠*
├───────────────────
┃➢ ${prefix}tp 1 - 162 / *Text*
┃➢ ${prefix}ep 1 - 216 / *Text*
┃➢ ${prefix}tahta *Text*
┃➢ ${prefix}cglitch *Text/bot*
┃➢ ${prefix}cglass *Text*
┃➢ ${prefix}cstyle *Text*
┃➢ ${prefix}clove *Text*
┃➢ ${prefix}cparty *Text*
┃➢ ${prefix}csky *Text*
┃➢ ${prefix}tts *Code Bahasa* *Text*
┃➢ ${prefix}ttp *ERROR⚠*
├───────────────────
┃➢ ${prefix}stiker *ERROR⚠*
┃➢ ${prefix}gifstiker *ERROR⚠*
┃➢ ${prefix}toimg
┃➢ ${prefix}img2url
┃➢ ${prefix}tomp3
┃➢ ${prefix}togif
┃➢ ${prefix}ocr
├───────────────────
┃➢ ${prefix}slow *Reply mp3/mp4*
┃➢ ${prefix}gemuk *Reply mp3/mp4*
┃➢ ${prefix}tupai *Reply mp3/mp4*
┃➢ ${prefix}bass *Reply mp3/mp4*
┃➢ ${prefix}toptt *Reply mp3/mp4*
┬
╰──────────────────────────
`
}
exports.creator = creator