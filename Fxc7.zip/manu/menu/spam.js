const spam = (prefix, pushname2, groupName, user, name) => {
return `

╭─────≽「 *REGULATION ${name}* 」
┴
┃❀° \`\`\`NAMA USER:\`\`\` *${pushname2}*
┃❀° \`\`\`NAMA GRUP:\`\`\` *${groupName}*
┃❀° \`\`\`VERSION:\`\`\` *0.0.0*
┃❀° \`\`\`USER TERDAFTAR:\`\`\` *${user.length} User*
┬
╰────────────────────────

╭─────≽「 *SPAMMER MENU* 」
┴
┃➢ ${prefix}spamcall *083xxxxxxxxx*
┃➢ ${prefix}spamgmail *contoh@gmail.com*
┬
╰────────────────────────
`
}
exports.spam = spam