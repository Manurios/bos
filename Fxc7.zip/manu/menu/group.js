const groupp = (prefix, pushname2, groupName, user, name) => {
return `

╭─────≽「 *REGULATION ${name}* 」
┴
┃❀° \`\`\`NAMA USER:\`\`\` ${pushname2}*
┃❀° \`\`\`NAMA GRUP:\`\`\` ${groupName}*
┃❀° \`\`\`VERSION:\`\`\` *0.0.0*
┃❀° \`\`\`USER TERDAFTAR:\`\`\` ${user.length} User*
┬
╰────────────────────────

╭──≽「 *AKTIFKAN JIKA DIPERLUKAN* 」
┴
┃➢ ${prefix}antilink *On/Off*
┃➢ ${prefix}welcome *On/Off*
┃➢ ${prefix}grup *buka/tutup*
┃➢ ${prefix}modeanime *On/Off*
┃➢ ${prefix}nsfw *On/Off*
┃➢ ${prefix}simih *On/Off*
┃➢ ${prefix}bott *on/off*
┃➢ ${prefix}antivirtex *on/off*
┬
╰────────────────────────

╭──────≽「 *ANIME* 」
┴
┃➢ ${prefix}neonime *naruto*
┃➢ ${prefix}naruto
┃➢ ${prefix}minato
┃➢ ${prefix}boruto
┃➢ ${prefix}hinata
┃➢ ${prefix}sakura
┃➢ ${prefix}sasuke
┃➢ ${prefix}toukachan
┃➢ ${prefix}megumin
┃➢ ${prefix}rize
┃➢ ${prefix}akira
┃➢ ${prefix}itori
┃➢ ${prefix}kurumi
┃➢ ${prefix}miku
┃➢ ${prefix}anime
┃➢ ${prefix}animecry
┃➢ ${prefix}animekiss
┬
╰───────────────────────

╭──────≽「 *GROUP ONLY ADMIN* 」
┴
┃➢ ${prefix}fitnah *@mentioned/isi/balasan*
┃➢ ${prefix}ownergrup
┃➢ ${prefix}setpp *Send Image*
┃➢ ${prefix}infogrup
┃➢ ${prefix}add *628xxxxxxxxxx*
┃➢ ${prefix}kick *@mentioned*
┃➢ ${prefix}kicktime *@mentioned*
┃➢ ${prefix}promote *@mentioned*
┃➢ ${prefix}demote *@mentioned*
┃➢ ${prefix}setname
┃➢ ${prefix}setdesc
┃➢ ${prefix}linkgrup
┃➢ ${prefix}tagme
┃➢ ${prefix}wame
┃➢ ${prefix}nyimak
┃➢ ${prefix}hidetag
┃➢ ${prefix}tagall
┃➢ ${prefix}mentionall
┃➢ ${prefix}adminlist
┬
╰────────────────────────

╭──────≽「 *ANIME HOT* 」
┴
┃➢ ${prefix}nsfwloli*
┃➢ ${prefix}nsfwpussy*
┃➢ ${prefix}nsfwclasic*
┃➢ ${prefix}nsfwyuri*
┃➢ ${prefix}nsfwlewd*
┃➢ ${prefix}nsfwsolo*
┃➢ ${prefix}nsfweron*
┃➢ ${prefix}nsfwparadise*
┃➢ ${prefix}nsfwbigtt*
┃➢ ${prefix}nsfwecchi*
┃➢ ${prefix}nsfwcum*
┃➢ ${prefix}nsfwblowjob*
┃➢ ${prefix}nsfwneko*
┃➢ ${prefix}nsfwtrap*
┃➢ ${prefix}hentai*
┬
╰────────────────────────
`
}
exports.groupp = groupp