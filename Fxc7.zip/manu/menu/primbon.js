const primbon = (prefix, pushname2, groupName, user, name) => {
return `

╭─────≽「 *REGULATION ${name}* 」
┴
┃❀° \`\`\`NAMA USER:\`\`\` *${pushname2}*
┃❀° \`\`\`NAMA GRUP:\`\`\` *${groupName}*
┃❀° \`\`\`VERSION:\`\`\` *0.0.0*
┃❀° \`\`\`USER TERDAFTAR:\`\`\` *${user.length} User*
┬
╰────────────────────────

╭─────≽「 *PRIMBON MENU* 」
┴
┃➢ ${prefix}apakah *Question*
┃➢ ${prefix}kapankah *Question*
┃➢ ${prefix}bisakah *Question*
┃➢ ${prefix}rate *Name/@mentioned*
┃➢ ${prefix}watak *Name/@mentioned*
┃➢ ${prefix}hobby *Name/@mentioned*
┃➢ ${prefix}gantengcek *Name/@mentioned*
┃➢ ${prefix}cantikcek *Name/@mentioned*
┃➢ ${prefix}persengay *Name/@mentioned*
┃➢ ${prefix}pbucin *Name/@mentioned*
┃➢ ${prefix}mimpi *Question*
┃➢ ${prefix}artinama *Name*
┃➢ ${prefix}pasangan *Name/Name*
┃➢ ${prefix}tanggaljadian *Date/Month/Year*
┃➢ ${prefix}zodiak *Question*
┬
╰────────────────────────
` 
}
exports.primbon = primbon