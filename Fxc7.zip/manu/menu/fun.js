const fun = (prefix, pushname2, groupName, user, name) => {
return `

╭─────≽「 *REGULATION ${name}* 」
┴
┃❀°  \`\`\`NAMA USER:\`\`\` *${pushname2}*
┃❀°  \`\`\`NAMA GRUP:\`\`\` *${groupName}*
┃❀°  \`\`\`VERSION:\`\`\` *0.0.0*
┃❀°  \`\`\`USER TERDAFTAR:\`\`\` *${user.length} User*
┬
╰────────────────────────

╭─────≽「 *FUN MENU* 」
┴
┃➢ ${prefix}truth
┃➢ ${prefix}dare
┃➢ ${prefix}readmore *Te/xt*
┃➢ ${prefix}asupan
┃➢ ${prefix}tebakgambar
┃➢ ${prefix}caklontong
┃➢ ${prefix}family100
┃➢ ${prefix}meme
┃➢ ${prefix}memeindo
┃➢ ${prefix}darkjokes
┃➢ ${prefix}kalkulator *Number(× + - ÷)Number*
┬
╰────────────────────────
`
}
exports.fun = fun