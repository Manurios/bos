const scrapper = (prefix, pushname2, groupName, user, name) => {
return `
╭─────≽「 *REGULATION ${name}* 」
┴
┃❀°  \`\`\`NAMA USER:\`\`\` *${pushname2}*
┃❀°  \`\`\`NAMA GRUP:\`\`\` *${groupName}*
┃❀°  \`\`\`VERSION:\`\`\` *0.0.0*
┃❀°  \`\`\`USER TERDAFTAR:\`\`\` *${user.length} User*
┬
╰────────────────────────

╭──≽「 *STORY & SCRAPPER MENU* 」
┴
┃➢ ${prefix}cersex
┃➢ ${prefix}randombokep
┃➢ ${prefix}pornhub *stepMoms*
┃➢ ${prefix}xvideos* japan*
┃➢ ${prefix}xnxx *japan*
┃➢ ${prefix}nekopoi *oni chichi*
┬
╰────────────────────────
`
}
exports.scrapper = scrapper