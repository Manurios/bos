const informasi = (prefix, pushname2, groupName, user, name) => {
return `
╭─────≽「 *REGULATION ${name}* 」
┴
┃❀° \`\`\`NAMA USER:\`\`\` *${pushname2}*
┃❀° \`\`\`NAMA GRUP:\`\`\` *${groupName}*
┃❀° \`\`\`VERSION:\`\`\` *0.0.0*
┃❀° \`\`\`USER TERDAFTAR:\`\`\` *${user.length} User*
┬
╰────────────────────────

͏͏͏͏͏͏͏͏͏͏͏͏͏͏╭────≽「 *INFORMATION MENU* 」
┴
┃➢ ${prefix}jadwaltvnow *Channel Tv*
┃➢ ${prefix}trendtwit *Untuk Melihat Trend di Twitter*
┃➢ ${prefix}google berita terkini *Berita Terkini*
┃➢ ${prefix}kbbi *Kamus Besar Bahasa Indonesia*
┃➢ ${prefix}bahasa *Untuk Melihat Kode Bahasa*
┃➢ ${prefix}infogempa *Wilayah Terkena Gempa*
┃➢ ${prefix}infonomor *Nomor*
┃➢ ${prefix}infoalamat jalan *Kota*
├───────────────────
┃➢ ${prefix}lirik *Song*
┃➢ ${prefix}chord *Song*
┃➢ ${prefix}wiki *Question*
┃➢ ${prefix}brainly *Question*
┃➢ ${prefix}resepmasakan *Question*
┃➢ ${prefix}map *Kota*
┃➢ ${prefix}wattpad *Judul*
├───────────────────
┃➢ ${prefix}film *Film*
┃➢ ${prefix}pinterest *Gambar Yang Ingin Dicari*
┃➢ ${prefix}infocuaca *Kota*
┃➢ ${prefix}jamdunia *Kota*
┃➢ ${prefix}jarak *Kota1/Kota2*
┃➢ ${prefix}translate *en/Apa kabar?*
┃➢ ${prefix}playstore *Apk Yang Ingin Dicari*
┃➢ ${prefix}ytsearch *Apa Yang Ingin Dicari*
┃➢ ${prefix}moddroid *ApkMod Yang ingin Dicari*
┃➢ ${prefix}happymod *ApkMod Yang ingin Dicari*
┃➢ ${prefix}kalkulator *Angka*
┬
╰────────────────────────
`
}
exports.informasi = informasi