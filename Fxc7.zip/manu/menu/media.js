const mediaa = (prefix, pushname2, groupName, user, name) => {
return `

╭─────≽「 *REGULATION ${name}* 」
┴
┣⊱  \`\`\`NAMA USER:\`\`\` *${pushname2}*
┣⊱  \`\`\`NAMA GRUP:\`\`\` *${groupName}*
┣⊱  \`\`\`VERSION:\`\`\` *0.0.0*
┣⊱  \`\`\`USER TERDAFTAR:\`\`\` *${user.length} User*
┬
╰────────────────────────

͏͏͏͏͏͏͏͏͏͏͏͏͏͏╭─────≽「 *MEDIA MENU & DOWNLOAD* 」
┴
┠≽ *${prefix}tiktokstalk username*
┠≽ *${prefix}igstalk _farhan_xcode7*
┠≽ *${prefix}tiktoksearch dayana*
┠≽ *${prefix}instavid link valid*
┠≽ *${prefix}instaimg link valid*
┠≽ *${prefix}instastory username*
┠≽ *${prefix}ssweb url*
┠≽ *${prefix}url2img Url*
┠≽ *${prefix}tiktok*
┠≽ *${prefix}fototiktok*
┠≽ *${prefix}kbbi*
┠≽ *${prefix}wait*
┠≽ *${prefix}google berita terkini*
┬
╰────────────────────────
`
 }

exports.mediaa = mediaa