const menupremium = (prefix, pushname2, groupName, user, name, premium) => {
return `
╭─────≽「 *REGULATION ${name}* 」
┴
┃❀°  \`\`\`NAMA USER:\`\`\` *${pushname2}*
┃❀°  \`\`\`NAMA GRUP:\`\`\` *${groupName}*
┃❀°  \`\`\`VERSION:\`\`\` *0.0.0*
┃❀°  \`\`\`USER PREMIUM:\`\`\` *${premium.length} User*
┃❀°  \`\`\`USER TERDAFTAR:\`\`\` *${user.length} User*
┬
╰────────────────────────

╭───────≽「 *PREMIUM ONLY* 」
┴
┃➢ ${prefix}playmp3 *Song*
┃➢ ${prefix}fb *Url Video*
┃➢ ${prefix}snack *Url*
┃➢ ${prefix}ytmp3 *Url*
┃➢ ${prefix}ytmp4 *Url*
┃➢ ${prefix}joox *Song/Singer*
┃➢ ${prefix}smule *Url*
┬
╰────────────────────────
`
}
exports.menupremium = menupremium